function UpdateTime() {
    let obecnyCzas = new Date();
    let obecnyCzasUTC = obecnyCzas.toUTCString();
 
    document.getElementById("dataczas").innerHTML = obecnyCzasUTC;
 }
 
 setInterval(UpdateTime, 1000);