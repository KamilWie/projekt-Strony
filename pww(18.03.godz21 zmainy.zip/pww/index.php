<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sulyvahn</title>
    <link rel="stylesheet" href="styl8.css">
</head>
<body>
    <header>
    <img src="logo.png">    
    <h1>Sulyvahn</h1>
    <p>Witamy w Sulyvahn, drewnianym internetowym sklepie meblowym, posiadamy meble dopasowane do każdego rodzaju wnętrz, zapraszamy do zakupów.</p>
    </header>
<main>
    <div class="lewy">
  <h2>Aktualne w promocji:</h2>
        <?php
     //   $conn = mysqli_connect('localhost','root','','meble');
    //             $kw = "SELECT * FROM promocje;";
      //          $use = mysqli_query($conn, $kw);
      //          while($tab=mysqli_fetch_row($use)){
       //             echo '<div><h4>'.$tab[1].'</h4><img src="'.$tab[2].'"><p>wymiary: '.$tab[3].'<br>cena sprzed promocji: '.$tab[4].' zł'.'<br>promocyjna cena: '.$tab[5].' zł<br>data zakończenia: '.$tab[6].'</p></div>';
                    // trzeba dodać tabele promocje + w css ustawić aby na różnych rozdzielczościach strona była wyświetlana poprawnie
         //       }
        ?>
          
            </div>
    <div class="prawy">
    <h2>Dostępne produkty:</h2>
    <div class="produkty">
    <?php
                $conn = mysqli_connect('localhost','root','','meble');
                $kw = "SELECT * FROM produkty;";
                $use = mysqli_query($conn, $kw);
                while($tab=mysqli_fetch_row($use)){
                    echo '<div><h4>'.$tab[1].'</h4><img src="'.$tab[2].'"><p>wymiary: '.$tab[3].'<br>cena: '.$tab[4].' zł'.'</p></div>';
                }
            ?>
    </div>
            </div>
</main>
<footer>
    Stronę wykonali: Krzysztof Widziniewicz i Kamil Wierzgała
    <p id="dataczas"></p>
</footer>

<script src="script.js" ></script> 
</body>
</html>